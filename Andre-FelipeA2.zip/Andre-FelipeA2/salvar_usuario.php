<?php
include 'conexao.php';
// Capturar os dados do formulário
$nome = trim($_POST['nome']);
$email = trim($_POST['email']);
$data_nascimento = $_POST['data_nascimento'];
$telefone = trim($_POST['telefone']);
$senha = $_POST['senha'];
// Validar os dados (como feito anteriormente)
// Preparar a instrução SQL usando PDO para inserir os dados na tabela
$sql = "INSERT INTO usuarios (nome, email, data_nascimento, telefone, senha)
 VALUES (:nome, :email, :data_nascimento, :telefone, :senha)";
$stmt = $conn->prepare($sql);
// Bind dos parâmetros
$stmt->bindParam(':nome', $nome);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':data_nascimento', $data_nascimento);
$stmt->bindParam(':telefone', $telefone);
$stmt->bindParam(':senha', $senha);
// Executar a instrução
try {
 $stmt->execute();
echo "Usuário cadastrado com sucesso!";
} catch(PDOException $e) {
echo "Erro: " . $e->getMessage();
}
$conn = null; // Fechar conexão
?>