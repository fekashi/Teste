<!DOCTYPE html>
<htmllang="pt-BR">
<head>
 <meta charset="UTF-8">
 <title>Formulário de Cadastro de Usuário</title>
 <link rel="stylesheet" href="styles.css">
 <script>
 // Função para aplicar máscara no campo de nome (impedir números)
functionmascaraNome(input) {
input.value = input.value.replace(/[0-9]/g, '');
 }
 // Função para aplicar máscara no campo de telefone (impedir letras)
functionmascaraTelefone(input) {
input.value = input.value.replace(/\D/g, '');
 }
 </script>
</head>
<body>
 <h2>Cadastro de Usuário</h2>
 <formaction="salvar_usuario.php" method="post">
 <label for="nome">Nome:</label>
 <input type="text" id="nome" name="nome" oninput="mascaraNome(this)">
 <label for="email">Email:</label>
 <input type="email" id="email" name="email">
 <label for="data_nascimento">Data de Nascimento:</label>
 <input type="date" id="data_nascimento" name="data_nascimento">
 <label for="telefone">Telefone:</label>
 <input type="tel" id="telefone" name="telefone" pattern="[0-9]{10,11}" oninput="mascaraTelefone(this)">
 <label for="senha">Senha:</label>
 <input type="password" id="senha" name="senha">
 <buttontype="submit">Salvar</button>
 </form>
 <a href="listar_usuarios.php">Listar Usuários</a>
</body>
</html>