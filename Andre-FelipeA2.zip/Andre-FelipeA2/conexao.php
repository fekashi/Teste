<?php
// Configurações do banco de dados
$hostname = 'localhost'; // Host do MySQL (geralmente localhost)
$dbname = 'seu_banco_de_dados'; // Nome do banco de dados
$username = 'seu_usuario'; // Nome de usuário do MySQL
$password = 'sua_senha'; // Senha do MySQL
// Configuração da conexão PDO
$options = array(
PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Modo de erro: exceção
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Modo de fetch padrão: array associativo
PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci" // UTF-8
);
// Conectar ao banco de dados usando PDO
try {
 $conn = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password, $options);
} catch(PDOException $e) {
 // Em caso de erro na conexão, exibe o erro
throw new PDOException($e->getMessage(), (int)$e->getCode());
}
?>